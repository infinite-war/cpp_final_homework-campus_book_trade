#pragma once

#include "login.h"
#include "dbmanager.h"
#include "register.h"


DbManager* DbManager::dba=NULL;
Account* Account::account=NULL;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QTranslator translator;
    const QStringList uiLanguages = QLocale::system().uiLanguages();
    for (const QString &locale : uiLanguages) {
        const QString baseName = "campus_" + QLocale(locale).name();
        if (translator.load(":/i18n/" + baseName)) {
            a.installTranslator(&translator);
            break;
        }
    }


    qDebug()<<"1111";
    //界面声明
    Login loginForm;
    //Register registerForm;

    loginForm.show();
    qDebug()<<"2222";


    //构造各个界面之间的连接
    //QObject::connect(&loginForm,SIGNAL(show_register_form()),&registerForm,SLOT(receive_from_login()));
    //QObject::connect(&registerForm,SIGNAL(show_login_form()),&loginForm,SLOT(receive_from_register()));


    return a.exec();
}
