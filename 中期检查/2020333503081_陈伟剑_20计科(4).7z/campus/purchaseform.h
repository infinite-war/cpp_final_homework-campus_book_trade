#pragma once
#ifndef PURCHASEFORM_H
#define PURCHASEFORM_H

#include <QWidget>
#include "dbmanager.h"

namespace Ui {
class PurchaseForm;
}

class PurchaseForm : public QWidget
{
    Q_OBJECT

public:
    explicit PurchaseForm(QWidget *parent = nullptr);
    ~PurchaseForm();

private:
    Ui::PurchaseForm *ui;
};

#endif // PURCHASEFORM_H
