#ifndef BOOKMANAGER_H
#define BOOKMANAGER_H


class BookManager
{
public:
    BookManager();
};

#endif // BOOKMANAGER_H
