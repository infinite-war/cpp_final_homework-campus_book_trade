#pragma once
#include "buyerform.h"
#include "ui_buyerform.h"

BuyerForm::BuyerForm(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::BuyerForm)
{
    ui->setupUi(this);

    //预设置model
    DbManager* dba=DbManager::get_dba();
    model=new QSqlTableModel(this->ui->booksTableView,dba->db);
}

BuyerForm::~BuyerForm()
{
    delete ui;
}

//获取私有对象
PasswordEditForm &BuyerForm::get_passwordEditForm(){return this->passwordEditForm;}



//=====================private slots===========================

//-----------自定义控件事件----------

/*
函数名：on_action_log_out_triggered()
功能：退出当前用户
*/
void BuyerForm::on_action_log_out_triggered()
{
    //退出操作待实现
    this->close();
    emit show_loginForm();
}


/*
函数名：goto_sellerForm_click()
功能：当前用户转到卖方界面
*/
void BuyerForm::goto_sellerForm_click()
{
    this->hide();
    emit show_sellerForm();
}

/*
函数名：on_actionchange_your_password_triggered()
功能：弹出修改密码界面
*/
void BuyerForm::on_actionchange_your_password_triggered()
{
    this->passwordEditForm.show();
}


/*
函数名：search_selling_book_click()
功能：查询所有在售书籍
*/
void BuyerForm::search_selling_book_click()
{
    model->setTable("book");
    Account* account=Account::get_account();


    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->setFilter(QString("owner!='%1' and selled=0").arg(account->get_id())); //筛选条件
    model->select();

    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ISBN"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("书名"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("作者"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("出版社"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("卖方"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("获取方式"));
    model->setHeaderData(6,Qt::Horizontal,QObject::tr("价格"));
    model->setHeaderData(7,Qt::Horizontal,QObject::tr("新旧程度"));
    model->setHeaderData(8,Qt::Horizontal,QObject::tr("售出状态"));
    model->removeColumn(0);//不显示id列

    this->ui->booksTableView->setModel(model);
    this->ui->booksTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);   //table界面设为不可编辑
}


/*
函数名：search_target_book_click()
功能：搜索指定书籍
*/
void BuyerForm::search_target_book_click()
{

    QString target=this->ui->searchBookTextbox->text();

    Account* account=Account::get_account();

    model->setTable("book");
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->setFilter(QString("owner!='%1' and bookName like '%"+target+"%' ;").arg(account->get_id()));//.arg(target)); //筛选条件
    model->select();

    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ISBN"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("书名"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("作者"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("出版社"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("卖方"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("获取方式"));
    model->setHeaderData(6,Qt::Horizontal,QObject::tr("价格"));
    model->setHeaderData(7,Qt::Horizontal,QObject::tr("新旧程度"));
    model->setHeaderData(8,Qt::Horizontal,QObject::tr("售出状态"));
    model->removeColumn(0);//不显示id列

    this->ui->booksTableView->setModel(model);
    this->ui->booksTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);   //table界面设为不可编辑
}



//--------接收其他窗口的信号-----------
void BuyerForm::receive_from_login()
{
    QSqlQueryModel* res=new QSqlQueryModel(this->ui->booksTableView);
    res->clear();
    this->ui->booksTableView->setModel(res);
    this->ui->ordersTableView->setModel(res);
    this->show();
}

void BuyerForm::receive_from_seller()
{
    QSqlQueryModel* res=new QSqlQueryModel(this->ui->booksTableView);
    res->clear();
    this->ui->booksTableView->setModel(res);
    this->ui->ordersTableView->setModel(res);
    this->show();
}


void BuyerForm::receive_from_passwdEdit()
{
    Account* account=Account::get_account();
    qDebug()<<"buyer"<<account->get_password();
}



