#include "all_headers.h"
#include "bookmanager.h"

BookManager::BookManager()
{

}
