#pragma once
#include "purchaseform.h"
#include "ui_purchaseform.h"

PurchaseForm::PurchaseForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PurchaseForm)
{
    ui->setupUi(this);
}

PurchaseForm::~PurchaseForm()
{
    delete ui;
}
