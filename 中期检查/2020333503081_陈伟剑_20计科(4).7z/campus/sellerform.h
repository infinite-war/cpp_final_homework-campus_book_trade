#pragma once
#ifndef SELLERFORM_H
#define SELLERFORM_H

#include "all_headers.h"
#include "account.h"
#include "dbmanager.h"
#include "passwordeditform.h"

namespace Ui {
class SellerForm;
}

class SellerForm : public QMainWindow
{
    Q_OBJECT

public:
    explicit SellerForm(QWidget *parent = nullptr);
    ~SellerForm();

    PasswordEditForm &get_passwordEditForm();

private slots:
    //自定义控件事件
    void on_action_log_out_triggered();
    void goto_buyerForm_click();
    void on_actionchange_your_password_triggered();
    void get_my_book_click();
    void search_target_book_click();
    void on_edit_botton_clicked();


    //接收其他窗口的信号
    void receive_from_buyer();
    void receive_from_passwdEdit();

signals:
    void show_buyerForm();
    void show_loginForm();

private:
    Ui::SellerForm *ui;
    PasswordEditForm passwordEditForm;
    QSqlTableModel* model;
};

#endif // SELLERFORM_H
