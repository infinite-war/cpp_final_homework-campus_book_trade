#pragma once
#include "sellerform.h"
#include "ui_sellerform.h"

SellerForm::SellerForm(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SellerForm)
{
    ui->setupUi(this);

    //预设置model
    DbManager* dba=DbManager::get_dba();
    model=new QSqlTableModel(this->ui->booksTableView,dba->db);
}

SellerForm::~SellerForm()
{
    delete ui;
}

//获取私有对象
PasswordEditForm &SellerForm::get_passwordEditForm(){return this->passwordEditForm;}



//=====================private slots===========================

//-----------自定义控件事件----------
void SellerForm::on_action_log_out_triggered()
{
    this->close();
    emit show_loginForm();
}

void SellerForm::goto_buyerForm_click()
{
    this->close();
    emit show_buyerForm();
}

/*
函数名：on_actionchange_your_password_triggered()
功能：弹出修改密码界面
*/
void SellerForm::on_actionchange_your_password_triggered()
{
    this->passwordEditForm.show();
}


/*
函数名：get_my_book_click()
功能：查询自己的书
*/
void SellerForm::get_my_book_click()
{
    model->setTable("book");
    Account* account=Account::get_account();


    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->setFilter(QString("owner='%1'").arg(account->get_id()));
    model->select();

    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ISBN"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("书名"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("作者"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("出版社"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("卖方"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("获取方式"));
    model->setHeaderData(6,Qt::Horizontal,QObject::tr("价格"));
    model->setHeaderData(7,Qt::Horizontal,QObject::tr("新旧程度"));
    model->setHeaderData(8,Qt::Horizontal,QObject::tr("售出状态"));
    model->removeColumn(0);//不显示id列

    this->ui->booksTableView->setModel(model);
}


/*
函数名：search_target_book_click()
功能：搜索指定书籍
*/
void SellerForm::search_target_book_click()
{

    QString target=this->ui->searchBookTextbox->text();

    Account* account=Account::get_account();

    model->setTable("book");
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
    model->setFilter(QString("owner='%1' and bookName like '%"+target+"%' ;").arg(account->get_id()));//.arg(target)); //筛选条件
    model->select();

    model->setHeaderData(0,Qt::Horizontal,QObject::tr("ISBN"));
    model->setHeaderData(1,Qt::Horizontal,QObject::tr("书名"));
    model->setHeaderData(2,Qt::Horizontal,QObject::tr("作者"));
    model->setHeaderData(3,Qt::Horizontal,QObject::tr("出版社"));
    model->setHeaderData(4,Qt::Horizontal,QObject::tr("卖方"));
    model->setHeaderData(5,Qt::Horizontal,QObject::tr("获取方式"));
    model->setHeaderData(6,Qt::Horizontal,QObject::tr("价格"));
    model->setHeaderData(7,Qt::Horizontal,QObject::tr("新旧程度"));
    model->setHeaderData(8,Qt::Horizontal,QObject::tr("售出状态"));
    model->removeColumn(0);//不显示id列

    this->ui->booksTableView->setModel(model);
}




/*
函数名：on_edit_botton_clicked()
功能：修改书籍信息后人工提交修改
*/
void SellerForm::on_edit_botton_clicked()
{
    model->submitAll();
}



//--------接收其他窗口的信号-----------
void SellerForm::receive_from_buyer()
{
    QSqlQueryModel* res=new QSqlQueryModel(this->ui->booksTableView);
    res->clear();
    this->ui->booksTableView->setModel(res);
    this->ui->ordersTableView->setModel(res);
    this->show();
}



void SellerForm::receive_from_passwdEdit()
{
    Account* account=Account::get_account();
    qDebug()<<"seller"<<account->get_password();
}

