#pragma once
#include "login.h"
#include "ui_login.h"
#include "buyerform.h"


Login::Login(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Login)
{
    ui->setupUi(this);

    this->ui->accountTextbox->setText("Mitchell");
    this->ui->passwordTextbox->setText("123456");

    this->registerForm=new Register;
    this->buyerForm=new BuyerForm;
    this->sellerForm=new SellerForm;

    //连接登录界面和注册界面
    QObject::connect(this,SIGNAL(show_registerForm()),this->registerForm,SLOT(receive_from_login()));
    QObject::connect(this->registerForm,SIGNAL(show_loginForm()),this,SLOT(receive_from_register()));

    //连接登录界面和买(卖)方界面
    QObject::connect(this,SIGNAL(show_buyerForm()),this->buyerForm,SLOT(receive_from_login()));
    QObject::connect(this->buyerForm,SIGNAL(show_loginForm()),this,SLOT(receive_from_buyer()));
    QObject::connect(this->sellerForm,SIGNAL(show_loginForm()),this,SLOT(receive_from_buyer()));

    //连接买方界面和买方界面
    QObject::connect(this->buyerForm,SIGNAL(show_sellerForm()),this->sellerForm,SLOT(receive_from_buyer()));
    QObject::connect(this->sellerForm,SIGNAL(show_buyerForm()),this->buyerForm,SLOT(receive_from_seller()));

    //连接修改密码界面和买(卖)方界面
    //买(卖)方界面类中已经内置了修改密码界面，所以只用建立修改密码界面到买(卖)方界面的单方面连接
    //买方界面修改密码，级联修改卖方界面
    QObject::connect(&(this->buyerForm->get_passwordEditForm()),SIGNAL(renew_account()),this->buyerForm,SLOT(receive_from_passwdEdit()));
    QObject::connect(&(this->buyerForm->get_passwordEditForm()),SIGNAL(renew_account()),this->sellerForm,SLOT(receive_from_passwdEdit()));
    //买方界面修改密码，级联修改卖方界面
    QObject::connect(&(this->sellerForm->get_passwordEditForm()),SIGNAL(renew_account()),this->buyerForm,SLOT(receive_from_passwdEdit()));
    QObject::connect(&(this->sellerForm->get_passwordEditForm()),SIGNAL(renew_account()),this->sellerForm,SLOT(receive_from_passwdEdit()));

}

Login::~Login()
{
    delete ui;
}

//==============自定义控件事件================

//进入注册界面
void Login::register_botton_click()
{
    this->hide();
    emit show_registerForm();
}


//登录事件
void Login::login_botton_click()
{
    //存储输入的账号信息
    QString id=this->ui->accountTextbox->text();
    QString passwd=this->ui->passwordTextbox->text();
    if(id.isEmpty() || passwd.isEmpty()){
        QMessageBox::warning(NULL,"error","用户名或密码未输入");
        return ;
    }

    //匹配数据库中的账号
    QString search=QString("select * from account"
                           " where id='%1' and password ='%2'").arg(id).arg(passwd);
    DbManager* dba=DbManager::get_dba();
    QSqlQuery res(dba->db);
    res.exec(search);
    if(!res.next()){
        QMessageBox::warning(NULL,"error","账号或密码错误");
        return ;
    }

    QString userId=res.value("id").toString();
    QString userPassword=res.value("password").toString();
    QString userPhone=res.value("phone").toString();
    QString userAddress=res.value("address").toString();
    Account* user=Account::get_account();
    user->renew_account(userId,userPassword,userPhone,userAddress);
    qDebug()<<userId<<userPassword<<userPhone<<userAddress;


    this->hide();
    emit show_buyerForm();

}




//============接收其他窗口发出的信号===========
void Login::receive_from_register()
{
    this->show();
}

void Login::receive_from_buyer()
{
    this->show();
}
